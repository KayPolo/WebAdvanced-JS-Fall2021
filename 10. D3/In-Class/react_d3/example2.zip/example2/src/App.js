import { Component } from 'react';
import './App.css';
import Chart from './Components/Chart';

class App extends Component{

  state = {
     data: [12,5,3,6,6,7,10],
      w: 500,
      h: 300,
      color:"gold"

  }

  render(){

    return(
      <>
        <h1>This is my Chart</h1>
        <Chart data  ={this.state.data} w={this.state.w} h={this.state.h} color={this.state.color}/>
      </>
    
    );
  }

}


export default App;
