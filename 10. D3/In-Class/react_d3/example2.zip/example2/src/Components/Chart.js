import { Component } from "react";
import * as d3 from 'd3';


class Chart extends Component{

    constructor(props){
        super(props);

        this.drawChart();
    }


    drawChart(){
        // const data = [12,5,3,6,6,7,10];
        // const w = 500;
        // const h = 300;

        const {data, h, w, color} = this.props;

        const svg = d3.select("body")
        .append("svg")
        .attr("viewBox", `0 0 ${w} ${h}`)
        .style("margin-left", 10+'%')
        .style("margin-right", 10+'%')
       


        d3.select('svg').selectAll('rect')
            .data(data)
            .enter()
            .append("rect")
            .attr("x", (d,i) => i*70 )
            .attr("y",(d,i)=>h-10 * d)
            .attr('width', 65)
            .attr ('height', (d,i)=>d*10)
            .attr("fill",color)            

    }



    



    render(){
        return(
            <div>
               
                <div id = {"#" + this.props.id}></div>
            </div>
        );
    }

}


export default Chart;