import React, { Component } from 'react';
import './App.css';
import Modal from './Modal/Modal';
import BarChart from './Chart/Chart';


class App extends Component{

  state = {

    

    data:[3,5,7,9,10,5,2],
    w:600,
    h:300,
    color: "gold"

  }

 
  
  render(){


    return(

      <div className = "App">
          <h1>Hello!!!!</h1>

          <BarChart data = {this.state.data} w = {this.state.w} h = {this.state.h} color = {this.state.color}></BarChart>
                 
      </div>

    );
  }


}



export default App;
