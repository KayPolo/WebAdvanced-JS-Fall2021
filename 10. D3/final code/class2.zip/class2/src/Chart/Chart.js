import React, {Component} from 'react';
import * as d3 from 'd3';

class BarChart extends Component {
    constructor(props){
        super(props);
        this.drawChart();
    }

    drawChart(){

        // const data = [12, 5, 3, 6, 6, 9, 10];
        // const w = 500;
        // const h = 300;

        const {data, h, w, color} = this.props;

        //Responsive chart
        //https://medium.com/@louisemoxy/a-simple-way-to-make-d3-js-charts-svgs-responsive-7afb04bc2e4b
      
        const svg = d3.select("body")
        .append("svg")
        // .attr("width", w)
        // .attr("height", h)
        .attr("viewBox", `0 0 ${w} ${h}`)
        .style("margin-left", 10+"%")
        .style("margin-right", 10+"%");
                        
        d3.select("svg").selectAll("rect")
            .data(data)
            .enter()
            .append("rect")
            .attr("x", (d, i) => i * 80)
            .attr("y", (d, i) => h - 10 * d)
            .attr("width", 65)
            .attr("height", (d, i) => d * 10)
            .attr("fill", color)
    }




    render(){
        return(
            <div id = {"#" + this.props.id}></div>
        );
    }
}

export default BarChart;
