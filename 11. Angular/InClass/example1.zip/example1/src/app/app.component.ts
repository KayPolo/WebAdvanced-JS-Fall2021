import { Component } from '@angular/core';
import data from "./data/data.json"

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title:string = "Title of my App";
  week:number=4;

  projects:{ id:any, img:string, title:string, description:string }[] =data;

}
