import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-tile',
  templateUrl: './tile.component.html',
  styleUrls: ['./tile.component.css']
})
export class TileComponent implements OnInit {

  @Input() title: any;
  @Input() img: any;
  @Input() description: any;
  @Input() id: any;
  @Input() info: any;

  hideBoolean:boolean = true;

  constructor() { }

  ngOnInit(): void {
  }

    showProject(){
      this.hideBoolean = false;
    }

    closeProject(){
      this.hideBoolean = true;
    }



}
