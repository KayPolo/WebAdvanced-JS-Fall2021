import { Component, OnInit, Input} from '@angular/core';


@Component({
  selector: 'app-tiles',
  templateUrl: './tiles.component.html',
  styleUrls: ['./tiles.component.css']
})

export class TilesComponent implements OnInit {

  @Input() title: any;
  @Input() description: any;
  @Input() img: any;
  @Input() id: any;
  @Input() info: any;

  hideBoolean:boolean = true;
  
  
  constructor() { }

  ngOnInit(): void {}
  showProject(){
    console.log(this.id)
    this.hideBoolean=false;
     
  }

  closeProject=()=>{
    console.log(this.id + "was closed")
    this.hideBoolean=true;
  }


}
