<template>
 
      <!-- <h1>Tiles</h1> -->

<div id={{id}}>
        <div class="tiles-container" @click="hideProject = !hideProject">
            
            <img v-bind:src="img"/>
            <h3>{{title}}</h3>
            <p class="description">{{description}}</p>
        </div>
      

      <div class="project-container" v-bind:class="{ hide: hideProject}">
          <div class="close" @click="hideProject = !hideProject">&#x2715;</div>
          <Project 
          v-bind:title="title"
          v-bind:img="img"
          v-bind:info="info"/>
      </div>
      
  </div>
</template>

<script>
import Project from './Project.vue'

export default {
  name: 'Tiles',
//   props:[img, title, description,info],
  props:['id','title', 'description', 'img', 'info'], 
  data(){
      return {
          hideProject:true
          }
  },
 
  components: {
    Project
  
  }
  
}
</script>


<style>

.tiles-container{
    width: calc(94vw / 3);
    margin: 1vw;
    margin-bottom: 50px;
    cursor: pointer;   

}

img{
    width: 100%;
    margin-bottom: 30px;
}

img:hover{
    filter: grayscale(0.75);
}

h3{
    font-size: 2rem;
    text-align: left;
    margin-bottom: 20px;

}

.description{
    font-size: 1.5rem;
    text-align: left;
    margin-top: 20px;
    margin-left: 0;
    color: white;
}


.project-container{
    width: 100vw;
    position: fixed;
    background-color: white;
    left: 0;
    top: 0;
    height: 100vh;
    overflow-y: scroll;
    color: dimgray;
    z-index: 20;
}

.close{
    z-index: 30;
    color: dimgray;
    font-size: 3rem;
    position: absolute;
    right: 50px;
    top: 50px;
    cursor: pointer;
  }

.hide{
    display: none;
    
}


</style>