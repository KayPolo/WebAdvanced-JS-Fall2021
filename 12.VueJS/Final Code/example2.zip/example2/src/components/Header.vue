<template>
  <div class="header-container">
    <!-- <h1 class="app-title">This is my header</h1> -->
    <h1 class="app-title">{{title}}</h1>
    <div class="header-image"></div>
</div>

</template>

<script>


export default {
  name: 'Header',
//   props:['title'],
    
props:{
    title:{
        type:String,
        default:"Title"
    }
},

  components: {

  }
}
</script>



<style>
    .header-container{
    
    position: relative; 
    height: 400px;
    width: 100vw;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 50px;

  }

  .header-image{    
    position: absolute;
    background-image: url('https://assets.awwwards.com/assets/images/pages/about-evaluation/header.jpg');
    background-size: cover;
    background-position: center; 
    height: 100%;
    width: 100%;
    top: 0;
    left: 0;
    opacity: 0.4;
    
    
}
  

  h1{
      font-size: 4rem;
      z-index: 1;
      
  }
  
</style>