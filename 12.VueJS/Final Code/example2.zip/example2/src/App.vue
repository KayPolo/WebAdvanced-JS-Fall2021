<template>
 
  <div id="app">

       <!-- <h1>Hellow World</h1> -->

      <Header title="Very Cool Websites"/>
      <!-- <Tiles 
      title="Project Tile" 
      description='No Description' 
      info="Some Info" 
      img="https://dreamkatcha.com/wp-content/uploads/2017/11/quality-web-design-1-scaled.jpg"/> -->
    
    
      <Tiles class="container" :key="project.id" v-for="project in projects"
      v-bind:title="project.title" 
      v-bind:description='project.description' 
      v-bind:info="project.info" 
      v-bind:img="project.img"/>

    
  </div>
  
</template>

<script>

import Header from './components/Header.vue'
import Tiles from './components/Tiles.vue'
import projectData from "./data/data.json";


export default {
  name: 'App',
  components: {
    Header,
    Tiles
  },
  data(){
    return{
      projects:projectData,

    }
  }
}
</script>



<style>

@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap');

*{
    margin: 0;
    padding: 0;
}

body{
    text-align: center;
    width: 100vw;
    background-color: rgb(40, 40, 40);
    color: white;
    font-family: 'Roboto', sans-serif;
    font-weight: 300;
}

h1{
    font-weight: 700;
    color: white;
}

h3{
    font-weight: 400;
}
.container{
  display: inline-flex;
}

</style>
