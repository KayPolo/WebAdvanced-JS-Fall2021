<template>
    <div id="app">
        <!-- <h1>Hello {{name}}</h1> -->
        <Header text="Very Cool Websites"/>

        <Tiles
          id = "myId"
          img = "https://miro.medium.com/max/1200/1*rDBrq7YU7oLwZufdrX1uaA.png"
          title="Project Title"
          description = "Some text here"
        />
    </div>

</template>


<script>

    import Header from './components/Header.vue'
    import Tiles from './components/Tiles.vue'

    export default {
      name: 'App',

      components:{

        Header,
        Tiles

      },

      data(){
        return{
          name:'Karla'
        }

      }

    }

</script>




<style>

  @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap');

*{
    margin: 0;
    padding: 0;
}

body{
    text-align: center;
    width: 100vw;
    background-color: rgb(40, 40, 40);
    color: white;
    font-family: 'Roboto', sans-serif;
    font-weight: 300;
}

h1{
    font-weight: 700;
    color: white;
}

h3{
    font-weight: 400;
}
.container{
  display: inline-flex;
}

</style>
