<template>
    <div>

        <h1 class="title-h1">{{title}}</h1>
        <img v-bind:src='img'/>
        <p class="info">{{info}}</p>

    </div>
    
</template>

<script>
    export default{
        name:'Project',
        props:["title","img","info"]
    }

</script>


<style>
    .project-container{
    width: 100vw;
    position: fixed;
    background-color: white;
    left: 0;
    top: 0;
    height: 100vh;
    overflow-y: scroll;
    color: dimgray;
   

}


.info{
  font-size: 1.5rem;
  width: 90%;
  margin-left: 5%;
  text-align: left;
  margin-top: 50px;
}

img{
    object-fit: cover;
    height: 300px;
    width: 100vw;
    text-align: center;
    overflow-x: hidden;
    top: 0;
    margin-top: 0;
    color: dimgray;

  }

  .title-h1{
    font-size: 4rem;
    color: dimgray;
    margin: 50px;
    text-align: left;
  }


</style>