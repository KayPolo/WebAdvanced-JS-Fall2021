import React from 'react';
import './App.css';
import Header from './Components/Header/Hader'
import Carousel from './Components/Carousel/Carousel'

function App() {

  return (
    <div className="App">
      <Header/>
      <Carousel/>
    
    </div>
  );
}

export default App;
