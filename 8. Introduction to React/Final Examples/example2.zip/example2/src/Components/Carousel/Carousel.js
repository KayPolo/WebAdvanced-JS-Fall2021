//import React from 'react';
import React,{Component} from 'react';
import './Carousel.css'

// const Blocks  = ()=>{
 
//     return(
//         <div className = 'blocks'>
//             <div className = 'green block'></div>
//             <div className = 'yellow block'></div>
//             <div className = 'blue block'></div>
//         </div>
//     );

// }

// export default Blocks;



class Blocks extends Component {

  // So to ensure that the React. Component 
  // 's constructor() function gets called, we call 
  // super(props) . super(props) is a reference to 
  // the parents constructor() function, that's all 
  // it is. We have to add super(props) every single 
  // time we define a constructor() function inside a 
  // class-based component.

    constructor(props) {
      super(props);
    
      this.state = {
        changeOne: "",
        changeTwo: "",
        changeThree: "",
      }
    }
  
  
    boxOneClick = () => {
      this.setState({
        changeOne: "gold"
      })
    }

    boxTwoClick = () => {
        this.setState({
            changeTwo: "gray",
        })
      }

    boxThreeClick = () => {
        this.setState({
            changeThree: "black",
        })
    }  
  

    
    render() {
      return (
        <div className="blocks">
        <div className = 'green block'
            style={{backgroundColor: this.state.changeOne}}
             onClick={this.boxOneClick} 
        ></div>
       
        <div className = 'yellow block'
            style={{backgroundColor: this.state.changeTwo}}
            onClick={this.boxTwoClick} 
        ></div>

        <div className = 'blue block'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div>

  
        </div>
      );
    }
  }

  export default Blocks;